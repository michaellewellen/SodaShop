package school.mlewelllen.tomcatdemo;

public class brandObject {
	private String brand;
	private String company;

	public brandObject(String b, String c){
		brand = b;
		company = c;
	}

	public String getBrand(){
		return brand;
	}

	public String getCompany(){
		return company;
	}

	public void setBrand(String b){
		brand = b;
	}

	public void setCompany(String c){
		company = c;
	}
}
	


