package school.mlewelllen.tomcatdemo;

public enum SodaType{
	PEPSICO, COCACOLA, DRPEPPERSNAPPLE
	}

